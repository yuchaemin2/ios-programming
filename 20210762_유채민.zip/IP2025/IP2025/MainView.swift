//
//  MainView.swift
//  IP2025
//
//  Created by Chaemin Yu on 10/12/25.
//

import SwiftUI

struct MainView: View {
    var body: some View {
        Text("Main View")
    }
}

#Preview {
    MainView()
}
