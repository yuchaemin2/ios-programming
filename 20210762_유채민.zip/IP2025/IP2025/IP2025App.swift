//
//  IP2025App.swift
//  IP2025
//
//  Created by Chaemin Yu on 10/12/25.
//

import SwiftUI

@main
struct IP2025App: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
